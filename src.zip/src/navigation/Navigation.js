// navigation.js (or whatever you name it)
// @flow

import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';

// import your screen components
import {
  WELCOME_SCREEN,
  HOME_SCREEN,
  SIGNIN_SCREEN,
  // … other screens
} from './Screens';
import registerScreens from './registerScreens';

// IMPORTANT: registerScreens should export a mapping from screen names to React components
const screens = registerScreens();

const Stack = createNativeStackNavigator();

// Root navigator component
export function AppNavigator() {
  return (
    <NavigationContainer>
      <Stack.Navigator
        initialRouteName={WELCOME_SCREEN}
        screenOptions={{
          headerShown: false,
        }}
      >
        <Stack.Screen name={WELCOME_SCREEN} component={screens[WELCOME_SCREEN]} />
        <Stack.Screen name={SIGNIN_SCREEN} component={screens[SIGNIN_SCREEN]} />
        <Stack.Screen name={HOME_SCREEN} component={screens[HOME_SCREEN]} />
        {/* add more screens here */}
      </Stack.Navigator>
    </NavigationContainer>
  );
}
