// import { Navigation } from 'react-native-navigation';
const Navigation = 0;
import store from '../store/index';
export const resetRoot = () => {
  const { setDefaultOptions } = ('../navigation');
  setDefaultOptions();
  const user = store.getState().user && store.getState().user.get('userProfile')
  Navigation.setRoot({
    root: {
      bottomTabs: {
        children: [
          {
            stack: {
              children: [
                {
                  component: {
                    name: ('../navigation').screenIds.HOME_SCREEN,
                    options: {},
                  },
                },
              ],
              options: {
                bottomTab: {
                  text: 'Messages',
                  icon: 'https://cdn.pixabay.com/photo/2025/11/24/11/00/burano-9973925_1280.jpg',
                  testID: 'SIGNIN_SCREEN',
                },
              },
            },
          },
          {
            stack: {
              children: [
                {
                  component: {
                    name: ('../navigation').screenIds.LEADER_BOARD_SCREEN,
                    options: {},
                  },
                },
              ],
              options: {
                bottomTab: {
                  text: 'Leader Board',
                  icon: 'assets/icons/leader.png',
                  testID: 'SECOND_TAB_BAR_BUTTON',
                },
              },
            },
          },
          {
            stack: {
              children: [
                {
                  component: {
                    name: ('../navigation').screenIds.NOTIFICATION_SCREEN,
                    options: {},
                  },
                },
              ],
              options: {
                bottomTab: {
                  text: 'Notification',
                  icon: ('assets/icons/notification.png'),
                  testID: 'SECOND_TAB_BAR_BUTTON',
                },
              },
            },
          },
          {
            stack: {
              children: [
                {
                  component: {
                    name: ('../navigation').screenIds.PROFILE_SCREEN,
                    options: {},
                    passProps: {
                      myProfile: true,
                    },
                  },
                },
              ],
              options: {
                // topBar: {

                // },
                bottomTab: {
                  text: user && user.position&& user.position.layer=="C"?'Achievements' :'Qcoins Allocation',
                  icon: ('assets/icons/black-male.png'),
                  testID: 'SIGNIN_SCREEN',
                },
              },
            },
          },
        ],
        options: {
          bottomTabs: {
            currentTabIndex: 3,
          },
        },
      },
    },
  });
};

export const goToLogin = () => {
  const { setDefaultOptions } = ('../navigation');
  setDefaultOptions();

  Navigation.setRoot({
    root: {
      stack: {
        children: [
          {
            component: {
              name: ('../navigation').screenIds.SIGNIN_SCREEN,
              id: 'ssss',
              statusBar: {
                backgroundColor: '#005EB8',
                // style: 'dark',
                // backgroundColor: '005EB8',
                style: 'light',
              },
            },
          },
        ],
      },
    },
  });
};

const setRoot = () => {
  const { setDefaultOptions } = ('../navigation');
  console.log('START 1');
  Navigation.events().registerAppLaunchedListener(() => {
    console.log('START');
    setDefaultOptions();
      Navigation.setRoot({
        root: {
          component: {
            name: ('../navigation').screenIds.WELCOME_SCREEN,
            options: {
              topBar: {
                visible: false,
                drawBehind: true,
              },
              statusBar: {
                backgroundColor: '#005EB8',
                // style: 'dark',
                // backgroundColor: '005EB8',
                style: 'light',
              },
            },
          },
        },
      });
  });
};

export default setRoot;
