// AppNavigator.js
import React from 'react';
import { Provider } from 'react-redux';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import store from '../store';

// Import your screens
import {
  WelcomeScreen,
  WelcomeMessageScreen,
  SigninScreen,
  ChangePasswordScreen,
  HomeScreen,
  ProfileScreen,
  AddPostScreen,
  TagPeopleScreen,
  NotFoundScreen,
  LeaderBoardScreen,
  SettingScreen,
  ModalScreen,
  LikesScreen,
  UserInformationScreen,
  ChangePhotoModal,
  ChangePasswordScreen1,
  CommentsScreen,
  ForgetPasswordScreen,
  NotificationScreen,
  PostScreen,
  NewScreen,
  RedeemScreen,
  AboutScreen,
  PublicationScreen,
  // TermsScreen (if outside src/screens)
} from '../screens';

// import TermsScreen from 'src/screens/TermsScreen';

const Stack = createNativeStackNavigator();

function AppNavigator() {
  return (
    <Provider store={store}>
      <NavigationContainer>
        <Stack.Navigator
          initialRouteName="Welcome"
          screenOptions={{
            headerShown: false,
          }}
        >
          <Stack.Screen name="Welcome" component={WelcomeScreen} />
          <Stack.Screen name="WelcomeMessage" component={WelcomeMessageScreen} />
          <Stack.Screen name="Signin" component={SigninScreen} />
          <Stack.Screen name="ChangePassword" component={ChangePasswordScreen} />
          <Stack.Screen name="Home" component={HomeScreen} />
          <Stack.Screen name="Profile" component={ProfileScreen} />
          <Stack.Screen name="AddPost" component={AddPostScreen} />
          <Stack.Screen name="TagPeople" component={TagPeopleScreen} />
          <Stack.Screen name="NotFound" component={NotFoundScreen} />
          <Stack.Screen name="LeaderBoard" component={LeaderBoardScreen} />
          <Stack.Screen name="Setting" component={SettingScreen} />
          <Stack.Screen name="Modal" component={ModalScreen} />
          <Stack.Screen name="Likes" component={LikesScreen} />
          <Stack.Screen name="UserInformation" component={UserInformationScreen} />
          <Stack.Screen name="ChangePhoto" component={ChangePhotoModal} />
          <Stack.Screen name="ChangePassword1" component={ChangePasswordScreen1} />
          <Stack.Screen name="Comments" component={CommentsScreen} />
          <Stack.Screen name="ForgetPassword" component={ForgetPasswordScreen} />
          <Stack.Screen name="Notification" component={NotificationScreen} />
          <Stack.Screen name="Post" component={PostScreen} />
          <Stack.Screen name="New" component={NewScreen} />
          <Stack.Screen name="Redeem" component={RedeemScreen} />
          <Stack.Screen name="About" component={AboutScreen} />
          <Stack.Screen name="Publication" component={PublicationScreen} />
          {/* <Stack.Screen name="Terms" component={TermsScreen} /> */}
          {/* Add other screens similarly */}
        </Stack.Navigator>
      </NavigationContainer>
    </Provider>
  );
}

export default AppNavigator;
