const initialStore = {

};

export default initialStore;