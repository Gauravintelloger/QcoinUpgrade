// userSaga.js  

import { call, put, takeLatest, takeEvery } from 'redux-saga/effects';
import C from '../constants';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { Alert } from 'react-native';
import Snackbar from 'react-native-snackbar';

import { getApp } from '@react-native-firebase/app';
import messaging from '@react-native-firebase/messaging';

// Helper to check permission and get FCM token
async function checkPermissionAndGetToken() {
  const app = getApp();
  const msg = messaging(app);

  // On iOS: request permission; on Android: it's usually auto-granted (for API ≤ 32)
  const authStatus = await msg.requestPermission();
  const enabled =
    authStatus === msg.AuthorizationStatus.AUTHORIZED ||
    authStatus === msg.AuthorizationStatus.PROVISIONAL;

  if (!enabled) {
    return null;
  }

  // Register for remote messages (Android, iOS)
  await msg.registerDeviceForRemoteMessages();  // ensure device is registered

  // Get token
  let fcmToken = await AsyncStorage.getItem('fcmToken');
  if (!fcmToken) {
    fcmToken = await msg.getToken();
    if (fcmToken) {
      await AsyncStorage.setItem('fcmToken', fcmToken);
    }
  }
  return fcmToken;
}

function* login(action) {
  const { Api } = require("../../services");
  try {
    const deviceToken = yield call(checkPermissionAndGetToken);
    const response = yield call(Api.loginCall, {
      ...action.payload,
      deviceToken,
    });
    if (response.data) {
      if (response.data.message || response.data.errors) {
        yield put({ type: C.LOGIN_USER_FAILED, payload: { error: response.data.message } });
        Snackbar.show({
          text: response.data.message || 'Error occurred',
          backgroundColor: 'red',
          duration: Snackbar.LENGTH_LONG,
          action: {
            text: 'Okay',
            onPress: () => { Snackbar.dismiss(); },
          },
        });
      } else {
        yield call(AsyncStorage.setItem, 'user', JSON.stringify(response.data.user));
        yield call(AsyncStorage.setItem, 'token', response.data.access_token);
        yield call(AsyncStorage.setItem, 'firstTime', "yes");
        yield call(
          AsyncStorage.setItem,
          'changePassword',
          response.data.should_change_password ? 'yes' : 'no'
        );
        yield put({
          type: C.LOGIN_USER_SUCCEEDED,
          payload: {
            accessToken: response.data.access_token,
            changePassword: response.data.should_change_password,
            tokenType: response.data.token_type,
            user: response.data.user,
          },
        });

        // navigation logic — if you have RootNavigation or other navigator
        // if (response.data.should_change_password) { ... } else { ... }
      }
    }
  } catch (e) {
    console.warn(e);
    yield put({ type: C.LOGIN_USER_FAILED, payload: { error: e } });
  }
}

// ... rest of sagas (changePassword, updateImage, etc.) remain same

export default function* userSaga() {
  yield takeLatest(C.LOGIN_USER_REQUESTED, login);
  yield takeLatest(C.CHANGE_PASSWORD_REQUESTED, changePassword);
  yield takeEvery(C.GET_USER_PROFILE_REQUESTED, getUserProfile);
  yield takeLatest(C.GET_USER_DETAILS_REQUESTED, getUserDetails);
  yield takeLatest(C.FORGOT_PASSWORD_REQUESTED, forgotPassword);
  yield takeLatest(C.UPDATE_IMAGE_REQUESTED, updateImage);
}
