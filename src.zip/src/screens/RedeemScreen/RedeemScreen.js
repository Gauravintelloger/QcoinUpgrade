// @flow

import React, { PureComponent } from 'react';
import RedeemCard from './redeemCard'
import {
    StyleSheet,
    View,
    Image,
    Text,
    Dimensions,
    TouchableOpacity,
    ScrollView,
    ActivityIndicator,
    LayoutAnimation,
    UIManager,
    ImageBackground,
    Platform,
    TextInput,
    TouchableWithoutFeedback,
} from 'react-native';
UIManager.setLayoutAnimationEnabledExperimental &&
    UIManager.setLayoutAnimationEnabledExperimental(true);

// import FastImage from '@d11/react-native-fast-image';
import { screenIds, pop, push } from '../../navigation';
import { GluestackUIProvider, HStack, Box } from "@gluestack-ui/themed";
import { config } from "./gluestack-ui.config";
 import { Navigation } from 'react-native-navigation';
const Navigation = 0;
import Snackbar from 'react-native-snackbar';

import Post from '../../components/Post';
import { getRedeemsCall, requestRedeemCall, getUserProfileCall } from 'src/services/api/calls';
const { width, height } = Dimensions.get('window');
const dimensionsCalculation = IPhonePixel => {
    return (width * IPhonePixel) / 375;
};

const styles = StyleSheet.create({
    flex: {
        flex: 1,
        alignItems: 'center',
        justifyContent: 'center',
    },
    button: {
        backgroundColor: '#039893',
        width: 230,
        marginTop: 30,
        borderRadius: 25,
    },
    buttonTitle: {
        fontSize: 14,
        fontWeight: 'bold',
    },
    logo: {
        width: 300,
        height: 120,
        resizeMode: 'contain',
    },
    logoTitle: {
        marginTop: 10,
        fontSize: 16,
        fontWeight: '500',
    },
});

class RedeemScreen extends PureComponent {
    constructor(props) {
        super(props);
        this.state = {
            redeems: [],
            selectedRedeem: {},
            showRedeemForm: false,
            points: 0,
            userProfile:{}
        };
        Navigation.events().bindComponent(this);
    }

     componentDidMount() {
        this.getRedeems();
        this.getProfile()
    }


    getProfile= async ()=>{
        const response = await getUserProfileCall({userId: this.props.userProfile.id})
        this.setState({ 
            userProfile:response.data.user_info
        })
        this.props.getUserProfileCall({userId: this.props.userProfile.id})
    }
    
    getRedeems = async () => {
        const response = await getRedeemsCall();
        this.setState({
            redeems: response.data.redeems
        })
    }

    requestRedeem = async () => {
        let data = {
            redeem_id: this.state.selectedRedeem.id,
            points: this.state.points
        }

        const response = await requestRedeemCall(data)
        this.setState({
            selectedRedeem: {},
            points: 0
        })
        this.getProfile()

        if(response.data && response.data.message.toLowerCase() ==="request has been sent to admin"){
        
            Snackbar.show({
                text: response.data.message,
                type: 'danger',
                backgroundColor: 'red',

                duration: Snackbar.LENGTH_LONG,
                action: {
                    text: 'Okay',

                    onPress: () => { Snackbar.dismiss() },
                },
            });
            setTimeout(()=>{
                this.handlePressBack()
            },1500)
        }
        else{
            Snackbar.show({
                text: response.data.message,
                type: 'danger',
                backgroundColor: 'red',

                duration: Snackbar.LENGTH_LONG,
                action: {
                    text: 'Okay',

                    onPress: () => { Snackbar.dismiss() },
                },
            });
                this.handlePressBack()
        }
    }

    handlePressBack = () => {
        if(this.state.showRedeemForm){
            this.setState({
                showRedeemForm: false
            })
            this.getRedeems()
        }
        else{
            this.props.getRedeemRequests();
            pop(this.props.componentId);
        }
    };


    render() {
        return (
            <GluestackUIProvider config={config}>
            <Box flex={1} backgroundColor={'white'}>
                <HStack
                            flexDirection= {"column"}
                            paddingHorizontal= {dimensionsCalculation(16)}
                            backgroundColor= {'#005EB8'}
                            borderBottomWidth= {0}
                            alignItems= {'flex-start'}
                         height= {dimensionsCalculation(220)}
                >
                    <TouchableOpacity
                        onPress={this.handlePressBack}
                        style={{ flexDirection: 'row' }}>
                        <Image style={{marginLeft:10}} source={('../../assets/icons/left_arrow.png')} />
                        <Text
                            style={{
                                fontSize: dimensionsCalculation(20),
                                letterSpacing: dimensionsCalculation(0.2),
                                lineHeight: dimensionsCalculation(25),
                                color: '#fff',
                                marginHorizontal: dimensionsCalculation(5),
                                marginLeft: dimensionsCalculation(10),

                            }}>
                            REDEEM QCOINS
                        </Text>
                    </TouchableOpacity>

                    <View style={{ flexDirection: "row", marginTop: dimensionsCalculation(20) }}>
                        <Text
                            style={{
                                marginBottom: 10,
                                fontSize: dimensionsCalculation(24),
                                letterSpacing: dimensionsCalculation(2),
                                lineHeight: dimensionsCalculation(35),
                                color: '#fff',
                                flexDirection: 'row',
                                fontWeight: 'bold',
                                marginHorizontal: this.props.myProfile
                                    ? 0
                                    : dimensionsCalculation(8),
                            }}>
                            You have <Text style={{ color: "#f8bc1b", fontSize: dimensionsCalculation(26) }}>{this.state.userProfile.points}
                                <Image
                                    source={('../../assets/icons/money-bag.png')}
                                />
                            </Text> Qcoins
                            Redeem it with
                        </Text>
                    </View>
                </HStack>
                <ScrollView style={{ bottom: dimensionsCalculation(35) }}> 
                    { (!this.state.redeems || this.state.redeems.length == 0 )&& 
                        <Text style={{textAlign:"center",fontSize:dimensionsCalculation(22),marginTop:dimensionsCalculation(60)}}>No redeems added yet</Text>
                    }
                    {!this.state.showRedeemForm && this.state.redeems&& this.state.redeems.map((el) =>
                        <RedeemCard
                            id = {el.id}
                            redeemStatus = {el.status}
                            name={el.name}
                            change={el.change}
                            unit={el.unit}
                            number_of_points={el.number_of_points}
                            color={el.color}
                            icon={el.icon}
                            redeem={() => {
                                this.setState({
                                    showRedeemForm: true,
                                    selectedRedeem: el
                                })
                            }}
                        />
                    )}


                    {this.state.showRedeemForm &&
                        <View
                            style={{
                                flex: 1,
                                marginHorizontal: dimensionsCalculation(8),
                                backgroundColor: '#fff',
                                marginBottom: dimensionsCalculation(32),
                                borderRadius: dimensionsCalculation(12),
                                paddingHorizontal: dimensionsCalculation(14),
                                paddingTop: dimensionsCalculation(14),
                                shadowColor: '#3B3B3B',
                                shadowOpacity: 0.13,
                                shadowRadius: 22,
                                shadowOffset: {
                                    height: 6,
                                    width: 0,
                                },
                                elevation: 2,
                            }}>

                            <View style={{ margin: dimensionsCalculation(10) }}>
                                <View style={{ flexDirection: "row" }}>
                                {this.state.selectedRedeem.icon &&
                                    <Image
                                        source={{uri: this.state.selectedRedeem.icon}}
                                        style ={{
                                            height:dimensionsCalculation(40),
                                            aspectRatio: 1, 
                                            resizeMode: 'contain',
                                        }}
                                    />}
                                    <Text style={{
                                        marginVertical: dimensionsCalculation(2),
                                        marginBottom: dimensionsCalculation(15),
                                        marginLeft: dimensionsCalculation(10),
                                        fontSize: dimensionsCalculation(22),
                                        color: "#454545"
                                    }}>
                                        {this.state.selectedRedeem.name}
                                    </Text>
                                </View>

                                <View style={{ flexDirection: "row" }}>
                                    <Text style={{
                                        marginVertical: dimensionsCalculation(2),
                                        fontSize: dimensionsCalculation(19),
                                        color: "#797979",
                                        fontWeight: "bold"
                                    }}>
                                        Qcoins you want to spend
                                </Text>
                                </View>
                                <View style={{ flexDirection: "row", justifyContent: "space-between", borderBottomColor: '#dbdbdb', borderBottomWidth: 1 }}>
                                    <TextInput
                                        style={{ height: 40, width: "80%" }}
                                        onChangeText={points => this.setState({ points })}
                                        value={this.state.points}
                                        keyboardType={Platform.OS=="android" ? "numeric" : "number-pad"}

                                    />
                                    <Text
                                        style={{
                                            marginTop: dimensionsCalculation(10),
                                            fontSize: dimensionsCalculation(15),
                                            color: "#797979"
                                        }}
                                    >
                                        Qcoins
                                        </Text>
                                </View>

                                <View style={{ justifyContent: "center", flexDirection: "row", marginBottom: dimensionsCalculation(100), marginTop: dimensionsCalculation(30) }}>
                                    <TouchableOpacity style={{ width: "100%" }} onPress={this.requestRedeem}>
                                        <View style={{ backgroundColor: "#eaaa01", borderRadius: 10, width: "100%" }}>
                                            <Text style={{ color: "#fff", fontSize: dimensionsCalculation(15), textAlign: "center", paddingVertical: 10 }}>
                                                Send Request
                                                </Text>
                                        </View>
                                    </TouchableOpacity>
                                </View>
                            </View>
                        </View>
                    }
                </ScrollView>
            </Box>
            </GluestackUIProvider>
        );
    }
}

export default RedeemScreen;
