// @flow

import React, { Component } from 'react';
import {
  StyleSheet,
  View,
  Image,
  Text,
  Dimensions,
  TouchableOpacity,
  Keyboard,
  FlatList,
  SafeAreaView,
  LayoutAnimation,
  UIManager,
  ActivityIndicator,
  RefreshControl,
  Platform,
} from 'react-native';
UIManager.setLayoutAnimationEnabledExperimental &&
  UIManager.setLayoutAnimationEnabledExperimental(true);
import AsyncStorage from '@react-native-community/async-storage';

// import FastImage from '@d11/react-native-fast-image';
import { GluestackUIProvider, HStack, Box } from "@gluestack-ui/themed";
import { config } from "./gluestack-ui.config";

import Post from '../../components/Post';
import { push, screenIds, showModal } from '../../navigation';
import firebase from 'react-native-firebase';
import BranchFilter from 'src/components/BranchFiltera/BranchFilters';

const { width, height } = Dimensions.get('window');

const dimensionsCalculation = IPhonePixel => {
  return (width * IPhonePixel) / 375;
};

const styles = StyleSheet.create({
  flex: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
  },
  button: {
    backgroundColor: '#039893',
    width: 230,
    marginTop: 30,
    borderRadius: 25,
  },
  buttonTitle: {
    fontSize: 14,
    fontWeight: 'bold',
  },
  logo: {
    width: 300,
    height: 120,
    resizeMode: 'contain',
  },
  logoTitle: {
    marginTop: 10,
    fontSize: 16,
    fontWeight: '500',
  },
});

class HomeScreen extends Component {
  constructor(props) {
    super(props);
    this.state = {
      posts: [],
      nextPage: null,
      currentPage: 0,
      lastPage: 0,
      isRefreshing: false,
      selectedBranch: null,
      showBranchFilter: false,
      loading: true
    };
  }

  shouldComponentUpdate() {
    return true;
  }

  onLayout = () => {
    LayoutAnimation.configureNext(
      LayoutAnimation.create(350, 'easeInEaseOut', 'scaleXY'),
    );
  };
  async componentDidMount() {
    this.setState({
      loading: true
    })
    this.props.getPosts({});
    this.setState({
      loading: false
    })
    setTimeout(async()=>{
      const enabled = await firebase.messaging().hasPermission();
      console.log(enabled)
      if (enabled) {
        // NotificationConfig.getInitialLink()
        // NotificationConfig.getLink()
        firebase.notifications().onNotification(async (message) => {
          console.warn("message",message)
          const localNotification = new firebase.notifications.Notification()
            .setNotificationId(message.notificationId)
            .setTitle(message.title)
            .setData(message.data)
            .setBody(message.body);
  
          localNotification
            .ios.setBadge(0)
  
          if (Platform.OS === 'android') {
            const channel = new firebase.notifications.Android.Channel('aa-channel',
              'aaChannel', firebase.notifications.Android.Importance.Max)
              .setDescription('Instock channel');
  
            // Create the channel
            await firebase.notifications().android.createChannel(channel);
            localNotification
              .android.setChannelId(channel.channelId)
            // .android.setSmallIcon("'ic_launcher'");
          }
  
          firebase.notifications().displayNotification(localNotification).then((res) => {
          }).catch((err) => {
            console.log(err)
          })
        });
  
        firebase.notifications().onNotificationOpened((notificationOpen) => {
          // // Get the action triggered by the notification being opened
          // const action = notificationOpen.action;
          // // Get information about the notification that was opened
          // const notification = notificationOpen.notification;
          if (notificationOpen.notification.data.post_id) {
            // NotificationConfig.DeepLinkToPostDetails(notificationOpen.notification.data.post_id)
          }
  
        });
  
        firebase.notifications().getInitialNotification().then((notificationOpen) => {
          if (notificationOpen && notificationOpen.notification.data.post_id) {
            // NotificationConfig.DeepLinkToPostDetails(notificationOpen.notification.data.post_id)
          }
        })
      }
    },1000)
   
    this.checkPermission();
      this.createNotificationListeners(); //add this line
    // // Build a channel
    // const channel = new firebase.notifications.Android.Channel(
    //   'qc-channel',
    //   'QC Channel',
    //   firebase.notifications.Android.Importance.Max,
    // ).setDescription('Tajircom channel');

    // // Create the channel
    // firebase.notifications().android.createChannel(channel);

    // // this.notificationListener();
    // // this.notificationOpenedListener();
  }

  async checkPermission() {
    const enabled = await firebase.messaging().hasPermission();
    if (enabled) {
      this.getToken();
    } else {
      this.requestPermission();
    }
  }

  //3
  async getToken() {
    let fcmToken = await AsyncStorage.getItem('fcmToken');
    if (!fcmToken) {
      fcmToken = await firebase.messaging().getToken();
      if (fcmToken) {
        // user has a device token
        await AsyncStorage.setItem('fcmToken', fcmToken);
      }
    }
  }

  //2
  async requestPermission() {
    try {
      await firebase.messaging().requestPermission();
      // User has authorised
      this.getToken();
    } catch (error) {
      // User has rejected permissions
    }
  }



  handleNavigate = (notification1 = {}) => {
    if (notification1['gcm.notification.action_destination']) {
      showModal(
        screenIds.POST_SCREEN,
        {
          id: notification1['gcm.notification.action_destination'],
          // user: this.state.user
        },
        {
          layout: {
            backgroundColor: '#fff',
          },
          modalPresentationStyle: 'overCurrentContext',
          statusBar: {
            style: 'dark',
            backgroundColor: '#005EB8',
          },
        },
      );
    }
  };

  createNotificationListeners = async () => {
    /*
     * Triggered when a particular notification has been received in foreground
     * */
    this.notificationListener = firebase
      .notifications()
      .onNotification(notification => {
        console.log('onNotification' + notification.data)
        console.log(JSON.stringify(notification.data))
        const { title, body } = notification;
        if (Platform.OS === 'android') {
          // alert(notification.notificationId + "id" + notification.title + 'title' + notification.subtitle + 'subtitle' + notification.body)
          const localNotification = new firebase.notifications.Notification({
            sound: 'default',
            // show_in_foreground: true,
          })
            .setNotificationId('notificationId')
            .setTitle(notification.title)
            .setTitle(notification.title)
            .setSubtitle(notification.subtitle)
            .setBody(notification.body)
            .setData(notification.data)
            .android.setChannelId('qc-channel')
            .android.setSmallIcon('ic_launcher');
          // .android.setSmallIcon('ic_launcher');
          // .android.setChannelId('ic_notificationId') // e.g. the id you chose above
          // .android.setSmallIcon('ic_launcher') // create this icon in Android Studio
          // .android.setColor('#000000') // you can set a color here
          // .android.setPriority(firebase.notifications.Android.Priority.High);

          firebase
            .notifications()
            .displayNotification(localNotification)
            .catch(err => alert(err));
        } else if (Platform.OS === 'ios') {
          const localNotification = new firebase.notifications.Notification({
            sound: 'default',
          })
            .setNotificationId(notification.notificationId)
            .setTitle(notification.title)
            .setSubtitle(notification.subtitle)
            .setBody(notification.body)
            .setData(notification.data)
            .ios.setBadge(notification.ios.badge);

          firebase
            .notifications()
            .displayNotification(localNotification)
            .catch(err => console.error(err));
        }

        // this.showAlert(title, body);
      });

    /*
     * If your app is in background, you can listen for when a notification is clicked / tapped / opened as follows:
     * */
    this.notificationOpenedListener = firebase
      .notifications()
      .onNotificationOpened(notificationOpen => {
        const { title, body } = notificationOpen.notification || {};
        if (
          notificationOpen.notification &&
          notificationOpen.notification._notificationId
        )
          if (
            notificationOpen.notification &&
            notificationOpen.notification._data
          ) {
            // this.props.markNotificationAsRead({ id: notificationOpen.notification._notificationId })
            // this.showAlert(title, body);
            // if (this.props.accessToken)
            this.handleNavigate(notificationOpen.notification._data);
          }
      });

    /*
     * If your app is closed, you can check if it was opened by a notification being clicked / tapped / opened as follows:
     * */
    const notificationOpen = await firebase
      .notifications()
      .getInitialNotification();
    if (notificationOpen) {
      const { title, body } = notificationOpen.notification;
      if (
        notificationOpen.notification &&
        notificationOpen.notification._data
      ) {
        // this.showAlert(title, body);
        // if (this.props.accessToken)
        this.handleNavigate(notificationOpen.notification._data);
      }
    }
    /*
     * Triggered for data only payload in foreground
     * */
    this.messageListener = firebase.messaging().onMessage(message => {
      // this.props.getAllNotification({})
      //process data message
    });
  }

  displayNotification(message) {
    const notification = new firebase.notifications.Notification()
      .setNotificationId('notificationId')
      .setTitle('Queen Car')
      .setBody('Trip update..')
      .android.setChannelId('qc-channel')
      .android.setSmallIcon('ic_launcher');
    firebase.notifications().displayNotification(notification);
  }

  componentWillReceiveProps(nextProps) {
    if (
      this.props.allPosts.success != nextProps.allPosts.success &&
      nextProps.allPosts.success &&
      this.state.posts != nextProps.allPosts.list
    ) {
      this.onLayout();
      this.setState({
        posts: nextProps.allPosts.list,
        nextPage: nextProps.allPosts.next_page_url,
        currentPage: nextProps.allPosts.current_page,
        isRefreshing: false,
      });
    }

    if (this.props.tagedUser != nextProps.tagedUser && nextProps.tagedUser) {
      this.setState({
        loading: true
      })
      this.props.getPosts({
        branch: this.state.selectedBranch ? this.state.selectedBranch : "",
        name: nextProps.tagedUser.name
      });
      this.setState({
        loading: false
      })
    }
  }
  renderAddPost = () => {
    return (
      <View
        style={{
          position: 'absolute',
          top: dimensionsCalculation(Platform.OS === 'android' ? 64 : 90),
          zIndex: 99998,
          alignSelf: 'center',
          marginTop: dimensionsCalculation(8),
          marginBottom: dimensionsCalculation(24),
        }}>
        <TouchableOpacity
          onPress={() => {
            push(
              this.props.componentId,
              screenIds.ADD_POST_SCREEN,
              {},
              {
                bottomTabs: {
                  // titleDisplayMode: 'alwaysShow',
                  // height: 70,
                  visible: false,
                  animate: true,
                },
              },
            );
          }}
          activeOpacity={1}
          style={{
            height: dimensionsCalculation(60),
            width: dimensionsCalculation(365),
            backgroundColor: '#fff',
            borderRadius: dimensionsCalculation(12),
            shadowColor: '#3B3B3B',
            shadowOpacity: 0.22,
            shadowRadius: 22,
            shadowOffset: {
              height: 6,
              width: 0,
            },
            elevation: 2,
            flexDirection: 'row',
            alignItems: 'center',
            paddingHorizontal: dimensionsCalculation(24),
            marginTop: Platform.OS=="ios"? dimensionsCalculation(40):dimensionsCalculation(0),

          }}>
          <View
            style={{
              width: dimensionsCalculation(40),
              height: dimensionsCalculation(40),
              borderRadius: dimensionsCalculation(20),
              shadowColor: '#000000',
              shadowOpacity: 0.22,
              shadowRadius: 8,
              shadowOffset: {
                height: 3,
                width: 0,
              },
              elevation: 2,
            }}>
            {this.props.userProfile.image &&
            <Image
              source={{
                uri: this.props.userProfile.image,
              }}
              style={{
                width: '100%',
                height: '100%',
                borderRadius: dimensionsCalculation(20),
              }}
              resizeMode="cover"
            />}
          </View>
          <View
            style={{
              flex: 1,
              paddingHorizontal: dimensionsCalculation(16),
            }}>
            <Text
              style={{
                flexWrap: 'wrap',
                fontSize: dimensionsCalculation(15),
                color: '#717171',
                lineHeight: dimensionsCalculation(20),
                letterSpacing: dimensionsCalculation(0.2),
              }}>
              Add post ...
            </Text>
          </View>
        </TouchableOpacity>
      </View>
    );
  };

  renderPost = ({ item }) => {
    return <Post componentId={this.props.componentId} item={item} />;
  };

  fetchMore = () => {
    if (this.state.nextPage && this.state.currentPage != this.state.lastPage) {
      this.setState(
        {
          lastPage: this.state.currentPage,
        },
        () => {
          this.props.getPosts({ page: this.state.currentPage + 1, branch: this.state.selectedBranch ? this.state.selectedBranch : "", name: this.props.tagedUser ? this.props.tagedUser.name : "" });
        },
      );
    }
  };

  setBranch = (id) => {
    if (this.state.selectedBranch == id) {
      this.setState({
        selectedBranch: null,
        loading: true
      })

      this.props.getPosts({ name: this.props.tagedUser ? this.props.tagedUser.name : "" })
      this.setState({
        loading: false
      })
    }
    else {
      this.setState({
        selectedBranch: id,
        oading: true
      })
      this.props.getPosts({ branch: id, name: this.props.tagedUser ? this.props.tagedUser.name : "" })
      this.setState({
        loading: false
      })
    }
  }

  renderFooter = () => {
    if (this.props.allPosts.pending && !this.state.isRefreshing)
      return <ActivityIndicator size="large" />;
    else return <View style={{ height: dimensionsCalculation(60) }} />;
  };

  renderEmpty = () => {
    if (this.state.loading) {
      return (<ActivityIndicator size="large" />)
    }
    if (
      this.props.allPosts.success &&
      this.props.allPosts.list &&
      this.props.allPosts.list.length == 0
    )
      return (
        <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
          <Text> No Results found</Text>
        </View>
      );
    return null;
  };
  render() {
    let showAddPost = false;
    if (
      this.props.userProfile &&
      this.props.userProfile.position &&
      this.props.userProfile.position.layer !== 'C'
    )
      showAddPost = true;
    return (
      <GluestackUIProvider config={config}>
      <Box flex={1} backgroundColor={'#FCFCFC'}>
        {/* <SafeAreaView style={{ backgroundColor: '#005EB8' }}> */}
        <HStack
            paddingHorizontal= {dimensionsCalculation(16)}
            backgroundColor= {'#005EB8'}
            borderBottomWidth= {0}
            justifyContent= {'space-between'}
            height= {dimensionsCalculation(100)}
            alignItems= {'flex-start'}
          style={
            paddingTop= Platform.OS == "android" ? dimensionsCalculation(30) : dimensionsCalculation(50)
          }>
          <Text
            style={{
              marginTop:30,
              marginLeft:10,
              fontSize: dimensionsCalculation(20),
              letterSpacing: dimensionsCalculation(0.2),
              lineHeight: dimensionsCalculation(25),
              color: '#fff',
            }}>
            {'Messages Board'.toUpperCase()}
          </Text>
          <View style={{
            flexDirection: "row",
            alignItems:'center',
            marginTop:30
          }}>
            <TouchableOpacity
              activeOpacity={1}
              onPress={() =>
                push(
                  this.props.componentId,
                  screenIds.TAG_PEOPLE_SCREEN,
                  {
                    searchPosts: true,
                  },
                  {
                    bottomTabs: {
                      // titleDisplayMode: 'alwaysShow',
                      // height: 70,
                      visible: false,
                      animate: true,
                    },
                  },
                )
              }>
              <Image
                source={('../../assets/icons/search-icon.png')}
                style={{
                  marginHorizontal: 5,
                }}
              />
            </TouchableOpacity>
            {this.props.userProfile && this.props.userProfile.position && this.props.userProfile.position.layer !== 'C' &&
              (this.state.showBranchFilter ?
                <TouchableOpacity onPress={() => { this.setState({ showBranchFilter: false }) }}>
                  <Image
                    source={('../../assets/icons/bx-filter.png')}
                    style={{
                      marginHorizontal: 5,
                    }}
                  />
                </TouchableOpacity>
                :
                <TouchableOpacity onPress={() => { this.setState({ showBranchFilter: true }) }}>
                  <Image
                    source={('../../assets/icons/bx-filter-white.png')}
                    style={{
                      marginHorizontal: 5,
                    }}
                  />
                </TouchableOpacity>)
            }

          </View>

        </HStack>

        {showAddPost ? this.renderAddPost() : null}
        {showAddPost && Platform.OS == 'android' ? (
          <View style={{ height: dimensionsCalculation(40) }} />
        ) : null}
        <FlatList
          style={
            showAddPost
              ? { paddingTop: dimensionsCalculation(60), zIndex: -1 }
              : {}
          }
          refreshControl={
            <RefreshControl
              refreshing={this.state.isRefreshing}
              onRefresh={() => {
                this.setState(
                  { lastPage: 0, nextPage: null, posts: [], isRefreshing: true, loading: true },
                  () => {
                    this.props.getPosts({});
                    this.setState({
                      loading: false
                    })
                  },
                );
              }}
            />
          }
          showsVerticalScrollIndicator={false}
          // ListHeaderComponent={}
          // style={{ top: -dimensionsCalculation(15), }}
          data={this.state.posts}
          contentContainerStyle={{ backgroundColor: '#FCFCFC' }}
          renderItem={this.renderPost}
          keyExtractor={(item, index) => (item.id + 'jojo' + index).toString()}
          onEndReached={this.fetchMore}
          ListFooterComponent={this.renderFooter}
          ListEmptyComponent={this.renderEmpty}
          initialNumToRender={2}
          onEndReachedThreshold={0.7}
        // removeClippedSubviews={true}
        />
        {/* </SafeAreaView> */}
        <View style={{
          backgroundColor: "transparent",
          borderRadius: 100
        }}>
          {this.state.showBranchFilter &&
            <BranchFilter
              onPress={this.setBranch}
              selected={this.state.selectedBranch}
              hide={() => { this.setState({ showBranchFilter: false }) }}
            />
          }
        </View>
      </Box>
      </GluestackUIProvider>
    );
  }
}

export default HomeScreen;
