

import React, { PureComponent } from 'react';
import {
  StyleSheet,
  View,
  Image,
  Text,
  Dimensions,
  TouchableOpacity,
  FlatList,
  ActivityIndicator,
  LayoutAnimation,
  UIManager,
  ImageBackground,
  Platform,
  SafeAreaView
} from 'react-native';
// import FastImage from '@d11/react-native-fast-image';
import {
  showModal,
  screenIds,
  goToLogin,
  pop,
  push,
  dismissModal
} from '../../navigation';
// import { Navigation } from 'react-native-navigation';
const Navigation = 0;
import Post from '../../components/Post';

const { width, height } = Dimensions.get('window');
const dimensionsCalculation = IPhonePixel => (width * IPhonePixel) / 375;

const styles = StyleSheet.create({
  flex: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
  },
  button: {
    backgroundColor: '#039893',
    width: 230,
    marginTop: 30,
    borderRadius: 25,
  },
  buttonTitle: {
    fontSize: 14,
    fontWeight: 'bold',
  },
  logo: {
    width: 300,
    height: 120,
    resizeMode: 'contain',
  },
  logoTitle: {
    marginTop: 10,
    fontSize: 16,
    fontWeight: '500',
  },
});

UIManager.setLayoutAnimationEnabledExperimental &&
  UIManager.setLayoutAnimationEnabledExperimental(true);

class ProfileScreen extends PureComponent {
  constructor(props) {
    super(props);

    const initialUser = props.myProfile
      ? (props.userProfile || {})
      : (props.user || {});

    this.state = {
      isRefreshing: false,
      posts: [],
      nextPage: null,
      currentPage: 0,
      lastPage: 0,
      achievments: [],
      load: false,
      userDetails: { ...initialUser },
      user: { ...initialUser },
    };

    Navigation.events().bindComponent(this);
  }

  componentDidAppear() {
    if (this.props.myProfile) {
      this.props.getUserDetails({});
    }
  }

  componentDidMount() {
    this.props.getUserProfile({ userId: this.state.user.id });
  }

  componentDidUpdate(prevProps) {
    if (
      this.props.myProfile &&
      prevProps.userProfile.success !== this.props.userProfile.success &&
      this.props.userProfile.success
    ) {
      this.setState(prev => ({
        userDetails: {
          ...prev.userDetails,
          ...this.props.userProfile
        }
      }));
    }


    const userId = this.state.user.id;
    const prevPostsPayload = (prevProps.postsByUserId[userId] || {});
    const currPostsPayload = (this.props.postsByUserId[userId] || {});

    if (
      prevPostsPayload.success !== currPostsPayload.success &&
      currPostsPayload.success
    ) {
      this.onLayout();

      this.setState(prev => ({
        posts: currPostsPayload.list,
        nextPage: currPostsPayload.next_page_url,
        currentPage: currPostsPayload.current_page,
        lastPage: prev.currentPage,
        isRefreshing: false,
        achievments: currPostsPayload.achievments,
        load: true,
        userDetails: {
          ...prev.userDetails,
          ...(currPostsPayload.user_info || {})
        }
      }));
    }
  }


  getDisplayPoints = ({
    layer,
    position = {},
    points,
    given_points,
    points_to_give
  }) => {
    const posLayer = position.layer;
    const showRaw =
      layer === 'C' ||
      layer === 'B' ||
      posLayer === 'C' ||
      posLayer === 'B';

    if (showRaw) {
      // prefer `points`, then `given_points`, then 0
      return points ?? given_points ?? 0;
    } else {
      // else use points_to_give
      return points_to_give ?? 0;
    }
  };

  onLayout = () => {
    LayoutAnimation.configureNext(
      LayoutAnimation.create(350, 'easeInEaseOut', 'scaleXY'),
    );
  };

  fetchMore = () => {
    if (
      this.state.nextPage &&
      this.state.currentPage !== this.state.lastPage
    ) {
      this.props.getUserProfile({
        userId: this.state.user.id,
        page: this.state.currentPage + 1,
      });
    }
  };

  handlePressBack = () => {
    if (!this.props.myProfile) {
      pop(this.props.componentId);
    }
  };

  renderHeaderSection = (showAddPost = false) => {
    const {
      name = '',
      position = {},
      rank,
      image = 'https://images.unsplash.com/photo-1523676060187-f55189a71f5e',
    } = this.state.userDetails;

    let showRank = false;
    const UserLayer = this.props.userProfile?.position?.layer;
    const posLayer = position.layer;

    if (this.props.myProfile) {
      showRank = UserLayer !== 'A';
    } else {

      if (
        (UserLayer === 'C' && posLayer === 'C') ||
        (UserLayer === 'B' && posLayer === 'C') ||
        (UserLayer === 'A' && posLayer !== 'A')
      ) {
        showRank = true;
      }
    }

    const coins = this.getDisplayPoints(this.state.userDetails);

    return (
      <View
        style={{
          width: '100%',
          backgroundColor: '#005EB8',
          justifyContent: 'center',
          alignItems: 'center',
          paddingBottom: dimensionsCalculation(76),
        }}
      >
        <View
          style={{
            marginVertical: dimensionsCalculation(16),
            width: dimensionsCalculation(114),
            height: dimensionsCalculation(114),
            borderRadius: dimensionsCalculation(57),
            shadowColor: '#000',
            shadowOpacity: 0.16,
            shadowRadius: 8,
            shadowOffset: { height: 3, width: 0 },
            elevation: 2,
          }}
        >
          {/* <FastImage
            source={{ uri: image }}
            style={{
              width: '100%',
              height: '100%',
              borderRadius: dimensionsCalculation(57),
            }}
          /> */}
          {showRank && (
            <View
              style={{
                position: 'absolute',
                bottom: -dimensionsCalculation(15),
                justifyContent: 'center',
                alignItems: 'center',
                width: dimensionsCalculation(114),
              }}
            >
              <ImageBackground
                source={require('../../assets/icons/hexagon.png')}
                style={{
                  width: dimensionsCalculation(30),
                  height: dimensionsCalculation(33),
                  justifyContent: 'center',
                  alignItems: 'center',
                }}
              >
                <Text style={{ color: '#FFF' }}>{rank}</Text>
              </ImageBackground>
            </View>
          )}
        </View>

        <Text
          style={{
            fontSize: dimensionsCalculation(20),
            color: '#fff',
            letterSpacing: 0.2,
            lineHeight: dimensionsCalculation(24),
            marginBottom: dimensionsCalculation(8),
          }}
        >
          {name.toUpperCase()}
        </Text>
        <Text
          style={{
            fontSize: dimensionsCalculation(16),
            color: '#fff',
            letterSpacing: 0.2,
            lineHeight: dimensionsCalculation(20),
            fontWeight: '800',
          }}
        >
          {position.name}
        </Text>
        <Text
          style={{
            fontSize: dimensionsCalculation(20),
            color: '#fff',
            letterSpacing: 0.2,
            lineHeight: dimensionsCalculation(24),
            marginBottom: dimensionsCalculation(8),
          }}
        >
          <Text
            style={{
              fontSize: dimensionsCalculation(20),
              color: '#EAAA00',
              letterSpacing: 0.2,
              lineHeight: dimensionsCalculation(24),
              marginBottom: dimensionsCalculation(8),
              fontWeight: 'bold',
            }}
          >
            {coins}
          </Text>
          <Text style={{ fontWeight: 'bold' }}> Qcoins</Text>
        </Text>

        {showAddPost ? this.renderAddPost() : null}
      </View>
    );
  };

  showAchievements = () => {
    const posLayer = this.state.user.position.layer;
    if (!this.state.load) return null;
    if (this.props.userProfile.position.layer === 'C' && posLayer === 'B')
      return null;

    return (
      <View style={{ marginTop: dimensionsCalculation(8), marginBottom: dimensionsCalculation(24) }}>
        {(posLayer === 'C' || posLayer === 'B') && (
          <View
            style={{
              width: dimensionsCalculation(365),
              height: dimensionsCalculation(186),
              backgroundColor: '#fff',
              marginHorizontal: dimensionsCalculation(8),
              borderRadius: dimensionsCalculation(12),
              shadowColor: '#3B3B3B',
              shadowOpacity: 0.13,
              shadowRadius: 22,
              shadowOffset: { height: 6, width: 0 },
              elevation: 2,
              paddingVertical: dimensionsCalculation(16),
              justifyContent: 'space-between',
            }}
          >
            <Text
              style={{
                marginHorizontal: dimensionsCalculation(16),
                fontSize: dimensionsCalculation(16),
                color: '#005EB8',
              }}
            >
              Achievements
            </Text>
            {this.state.achievments.length === 0 ? (
              <View
                style={{
                  flex: 1,
                  justifyContent: 'center',
                  alignItems: 'center',
                }}
              >
                <Text
                  style={{
                    marginHorizontal: dimensionsCalculation(16),
                    fontSize: dimensionsCalculation(16),
                    color: '#005EB8',
                  }}
                >
                  You don't have any achievements yet!
                </Text>
              </View>
            ) : (
              <FlatList
                horizontal
                showsHorizontalScrollIndicator={false}
                data={this.state.achievments}
                renderItem={this.renderAchievmentCard}
                keyExtractor={(item, i) => item.reason + i}
              />
            )}
          </View>
        )}
      </View>
    );
  };

  renderAchievmentCard = ({ item }) => (
    <View style={{ marginHorizontal: dimensionsCalculation(9), alignItems: 'center' }}>
      <View
        style={{
          marginVertical: dimensionsCalculation(16),
          width: dimensionsCalculation(80),
          height: dimensionsCalculation(80),
          backgroundColor: '#fff',
          borderRadius: dimensionsCalculation(40),
          shadowColor: '#8A8A8A',
          shadowOpacity: 0.2,
          shadowRadius: 22,
          shadowOffset: { height: 6, width: 6 },
          elevation: 2,
          justifyContent: 'space-around',
          alignItems: 'center',
          padding: dimensionsCalculation(8),
        }}
      >
        {item.icon && (
          <Image
            source={{ uri: item.icon }}
            style={{ width: '100%', height: '100%', tintColor: item.color }}
            resizeMode="contain"
          />
        )}
        <Text style={{ color: item.color, fontSize: dimensionsCalculation(18) }}>
          {item.total}
        </Text>
      </View>
      <Text style={{ fontSize: dimensionsCalculation(16), color: '#005EB8' }}>
        {item.reason}
      </Text>
    </View>
  );

  renderPost = ({ item }) => (
    <Post
      componentId={this.props.componentId}
      item={item}
      myProfile={this.props.myProfile}
      user={this.state.user}
    />
  );

  renderFooter = () => {
    const pending = this.props.postsByUserId[this.state.user.id]?.pending;
    if (pending && !this.state.isRefreshing) {
      return (
        <ActivityIndicator
          size="large"
          style={{
            paddingTop: dimensionsCalculation(40),
            paddingBottom: dimensionsCalculation(40)
          }}
        />
      );
    }
    return null;
  };

  renderEmpty = () => {
    const { success, list } = this.props.postsByUserId[this.state.user.id] || {};
    if (success && list && list.length === 0) {
      return (
        <View style={{ flexDirection: 'row', justifyContent: 'center', marginTop: dimensionsCalculation(5) }}>
          <Text style={{ fontSize: 20 }}>No posts added yet</Text>
        </View>
      );
    }
    return null;
  };

  renderAddPost = () => (
    <View
      style={{
        position: 'absolute',
        bottom: -dimensionsCalculation(50),
        zIndex: 99998,
        alignSelf: 'center',
        marginTop: dimensionsCalculation(8),
        marginBottom: dimensionsCalculation(24),
      }}
    >
      <TouchableOpacity
        onPress={() => {
          push(
            this.props.componentId,
            screenIds.ADD_POST_SCREEN,
            {},
            {
              bottomTabs: {
                visible: false,
                animate: true,
                drawBehind: true,
              },
            }
          );
        }}
        activeOpacity={1}
        style={{
          height: dimensionsCalculation(60),
          width: dimensionsCalculation(365),
          backgroundColor: '#fff',
          borderRadius: dimensionsCalculation(12),
          shadowColor: '#3B3B3B',
          shadowOpacity: 0.22,
          shadowRadius: 22,
          shadowOffset: { height: 6, width: 0 },
          elevation: 2,
          flexDirection: 'row',
          alignItems: 'center',
          paddingHorizontal: dimensionsCalculation(24),
        }}
      >
        <View style={{ flex: 1, paddingHorizontal: dimensionsCalculation(16) }}>
          <Text
            style={{
              flexWrap: 'wrap',
              fontSize: dimensionsCalculation(15),
              color: '#717171',
              lineHeight: dimensionsCalculation(20),
              letterSpacing: 0.2,
            }}
          >
            add post …
          </Text>
        </View>
      </TouchableOpacity>
    </View>
  );

  render() {
    const showAddPost =
      this.props.userProfile?.position?.layer !== 'C';

    return (
      <SafeAreaView style={{ flex: 1, backgroundColor: '#005EB8' }}>
        <View
          style={[
            {
              paddingHorizontal: dimensionsCalculation(16),
              backgroundColor: '#005EB8',
              justifyContent: 'space-between',
              alignItems: 'flex-start',
              paddingTop: dimensionsCalculation(30),
              flexDirection: 'row',
            },
            Platform.OS === 'android'
              ? { height: dimensionsCalculation(70) }
              : {},
          ]}
        >
          <TouchableOpacity
            onPress={this.handlePressBack}
            style={{ flexDirection: 'row' }}
          >
            {!this.props.myProfile && (
              <Image
                style={{ marginLeft: 10 }}
                source={require('../../assets/icons/left_arrow.png')}
              />
            )}
            <Text
              style={{
                fontSize: dimensionsCalculation(20),
                letterSpacing: 0.2,
                lineHeight: dimensionsCalculation(25),
                color: '#fff',
                fontWeight: 'bold',
                marginHorizontal: this.props.myProfile
                  ? 0
                  : dimensionsCalculation(8),
              }}
            >
              {this.props.profile
                ? 'Profile'
                : (
                  this.props.userProfile.position.layer === 'A' ||
                  this.props.userProfile.position.layer === 'B'
                )
                  ? 'Allocation Of Qcoins'
                  : 'My Achievements'}
            </Text>
          </TouchableOpacity>

          {this.props.myProfile && (
            <TouchableOpacity
              hitSlop={{ top: 8, bottom: 8, left: 8, right: 8 }}
              onPress={() =>
                push(
                  this.props.componentId,
                  screenIds.SETTING_SCREEN,
                  { user: this.state.user },
                  {
                    bottomTabs: {
                      visible: false,
                      animate: false,
                      drawBehind: true,
                    },
                  }
                )
              }
              style={{ width: dimensionsCalculation(20), height: dimensionsCalculation(20) }}
            >
              <Image
                source={require('../../assets/icons/settings.png')}
                style={{ width: '100%', height: '100%' }}
              />
            </TouchableOpacity>
          )}
        </View>

        <View
          style={{
            backgroundColor: '#FFF',
            marginBottom: dimensionsCalculation(90),
          }}
        >
          {this.renderHeaderSection(showAddPost)}

          <FlatList
            style={
              showAddPost
                ? { zIndex: 9, paddingTop: dimensionsCalculation(60) }
                : { marginTop: -dimensionsCalculation(50) }
            }
            showsVerticalScrollIndicator={false}
            bounces={false}
            data={this.state.posts}
            renderItem={this.renderPost}
            keyExtractor={(item, i) => `${item.id}_post_${i}`}
            ListFooterComponent={this.renderFooter}
            ListEmptyComponent={this.renderEmpty}
            ListHeaderComponent={this.showAchievements}
            onEndReached={this.fetchMore}
            onEndReachedThreshold={0.7}
            initialNumToRender={2}
          />
        </View>
      </SafeAreaView>
    );
  }
}

export default ProfileScreen;








// import React, { PureComponent } from 'react';
// import {
//   StyleSheet,
//   View,
//   Image,
//   Text,
//   Dimensions,
//   TouchableOpacity,
//   Keyboard,
//   FlatList,
//   RefreshControl,
//   ScrollView,
//   ActivityIndicator,
//   LayoutAnimation,
//   UIManager,
//   ImageBackground,
//   Platform,
//   SafeAreaView
// } from 'react-native';
// import FastImage from 'react-native-fast-image';
// import { showModal, screenIds, goToLogin, pop, push, dismissModal } from '../../navigation';
// import { Navigation } from 'react-native-navigation';
// import Post from '../../components/Post';
// const { width, height } = Dimensions.get('window');
// const dimensionsCalculation = IPhonePixel => (width * IPhonePixel) / 375;

// const styles = StyleSheet.create({
//   flex: {
//     flex: 1,
//     alignItems: 'center',
//     justifyContent: 'center',
//   },
//   button: {
//     backgroundColor: '#039893',
//     width: 230,
//     marginTop: 30,
//     borderRadius: 25,
//   },
//   buttonTitle: {
//     fontSize: 14,
//     fontWeight: 'bold',
//   },
//   logo: {
//     width: 300,
//     height: 120,
//     resizeMode: 'contain',
//   },
//   logoTitle: {
//     marginTop: 10,
//     fontSize: 16,
//     fontWeight: '500',
//   },
// });

// UIManager.setLayoutAnimationEnabledExperimental &&
//   UIManager.setLayoutAnimationEnabledExperimental(true);

// class ProfileScreen extends PureComponent {
//   constructor(props) {
//     super(props);
//     this.state = {
//       isRefreshing: false,
//       posts: [],
//       nextPage: null,
//       currentPage: 0,
//       lastPage: 0,
//       user: props.myProfile ? props.userProfile || {} : props.user || {},
//       achievments: [],
//       userDetails: props.myProfile ? props.userProfile || {} : props.user || {},
//       load: false,
//     };
//     Navigation.events().bindComponent(this);
//   }

//   componentDidAppear() {
//     if (this.props.myProfile) this.props.getUserDetails({});
//   }

//   componentWillReceiveProps(nextProps) {
//     if (this.props.myProfile) {
//       if (
//         this.props.userProfile.success !== nextProps.userProfile.success &&
//         nextProps.userProfile.success
//       ) {
//         this.setState({
//           userDetails: nextProps.userProfile,
//         });
//       }
//     }
//     const propsPosts = this.props.postsByUserId[this.state.user.id] || {};
//     const nextPropsPosts = nextProps.postsByUserId[this.state.user.id] || {};
//     if (
//       propsPosts.success !== nextPropsPosts.success &&
//       nextPropsPosts.success
//     ) {
//       this.onLayout();
//       this.setState({
//         posts: nextPropsPosts.list,
//         nextPage: nextPropsPosts.next_page_url,
//         currentPage: nextPropsPosts.current_page,
//         isRefreshing: false,
//         achievments: nextPropsPosts.achievments,
//         load: true,
//         userDetails: nextPropsPosts.user_info ? nextPropsPosts.user_info : this.state.userDetails,
//       });
//     }
//   }

//   async componentDidMount() {
//     this.props.getUserProfile({ userId: this.state.user.id });
//   }

//   onLayout = () => {
//     LayoutAnimation.configureNext(
//       LayoutAnimation.create(350, 'easeInEaseOut', 'scaleXY'),
//     );
//   };

//   renderHeaderSection = (showAddPost = false) => {
//     const {
//       name = '',
//       position = {},
//       rank,
//       image = 'https://images.unsplash.com/photo-1523676060187-f55189a71f5e?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&w=1000&q=80',
//     } = this.state.userDetails;
//     let showRank = false;
//     const { position: UserPosition = {} } = this.props.userProfile || {};
//     const { layer: UserLayer } = UserPosition;

//     if (this.props.myProfile || (UserLayer === 'C' && position.layer === 'C'))
//       showRank = true;
//     if (this.props.myProfile || (UserLayer === 'B' && position.layer === 'C'))
//       showRank = true;
//     if (this.props.myProfile || (UserLayer === 'A' && position.layer !== 'A'))
//       showRank = true;
//     if (this.props.myProfile && UserLayer === 'A') showRank = false;

//     console.log('this.state.userDetails.points', this.state.userDetails.points);
//     console.log('this.state.userDetails.given_points', this.state.userDetails.given_points);
//     console.log('this.state.userDetails.points_to_give', this.state.userDetails.points_to_give);
//     console.log('this.state.userDetails.layer', this.state.userDetails.layer);
//     console.log('this.state.userDetails.position?.layer', this.state.userDetails.position?.layer);

//     return (
//       <View
//         style={{
//           width: '100%',
//           backgroundColor: '#005EB8',
//           justifyContent: 'center',
//           alignItems: 'center',
//           paddingBottom: dimensionsCalculation(76),
//         }}
//       >
//         <View
//           style={{
//             marginVertical: dimensionsCalculation(16),
//             width: dimensionsCalculation(114),
//             height: dimensionsCalculation(114),
//             borderRadius: dimensionsCalculation(114 / 2),
//             shadowColor: '#000000',
//             shadowOpacity: 0.16,
//             shadowRadius: 8,
//             shadowOffset: { height: 3, width: 0 },
//             elevation: 2,
//           }}
//         >
//           {image && (
//             <FastImage
//               source={{ uri: image }}
//               style={{
//                 width: '100%',
//                 height: '100%',
//                 borderRadius: dimensionsCalculation(114 / 2),
//               }}
//             />
//           )}
//           {showRank && (
//             <View
//               style={{
//                 position: 'absolute',
//                 bottom: -dimensionsCalculation(15),
//                 justifyContent: 'center',
//                 alignItems: 'center',
//                 width: dimensionsCalculation(114),
//               }}
//             >
//               <ImageBackground
//                 source={require('../../assets/icons/hexagon.png')}
//                 style={{
//                   width: dimensionsCalculation(30),
//                   height: dimensionsCalculation(33),
//                   justifyContent: 'center',
//                   alignItems: 'center',
//                 }}
//               >
//                 <Text style={{ color: '#FFFFFF' }}>{rank}</Text>
//               </ImageBackground>
//             </View>
//           )}
//         </View>
//         <Text
//           style={{
//             fontSize: dimensionsCalculation(20),
//             color: '#fff',
//             letterSpacing: dimensionsCalculation(0.2),
//             lineHeight: dimensionsCalculation(24),
//             marginBottom: dimensionsCalculation(8),
//           }}
//         >
//           {name.toUpperCase()}
//         </Text>
//         <Text
//           style={{
//             fontSize: dimensionsCalculation(16),
//             color: '#fff',
//             letterSpacing: dimensionsCalculation(0.2),
//             lineHeight: dimensionsCalculation(20),
//             fontWeight: '800',
//           }}
//         >
//           {position.name}
//         </Text>
//         <Text
//           style={{
//             fontSize: dimensionsCalculation(20),
//             color: '#fff',
//             letterSpacing: dimensionsCalculation(0.2),
//             lineHeight: dimensionsCalculation(24),
//             marginBottom: dimensionsCalculation(8),
//           }}
//         >
//           <Text
//             style={{
//               fontSize: dimensionsCalculation(20),
//               color: '#EAAA00',
//               letterSpacing: dimensionsCalculation(0.2),
//               lineHeight: dimensionsCalculation(24),
//               marginBottom: dimensionsCalculation(8),
//               fontWeight: 'bold',
//             }}
//           >
//             {this.state.userDetails.layer === "C" ||
//             this.state.userDetails.layer === "B" ||
//             this.state.userDetails.position?.layer === "C" ||
//             this.state.userDetails.position?.layer === "B"
//               ? (this.state.userDetails.points
//                   ? this.state.userDetails.points
//                   : this.state.userDetails.given_points
//                   ? this.state.userDetails.given_points
//                   : 0)
//               : this.state.userDetails.points_to_give
//               ? this.state.userDetails.points_to_give
//               : 0}
//           </Text>
//           <Text style={{ fontWeight: 'bold' }}> Qcoins</Text>
//         </Text>
//         {showAddPost ? this.renderAddPost() : null}
//       </View>
//     );
//   };

//   showAchievements = () => {
//     const {
//       name = '',
//       position = {},
//       rank,
//       image = 'https://images.unsplash.com/photo-1523676060187-f55189a71f5e?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&w=1000&q=80',
//     } = this.state.userDetails;
//     let showRank = false;
//     const { position: UserPosition = {} } = this.props.userProfile || {};
//     const { layer: UserLayer } = UserPosition;
//     if (UserLayer === 'C' && position.layer === 'B') return null;
//     if (!this.state.load) return null;

//     return (
//       <View
//         style={{
//           marginTop: dimensionsCalculation(8),
//           marginBottom: dimensionsCalculation(24),
//         }}
//       >
//         {(this.state.user.position.layer === 'C' ||
//           this.state.user.position.layer === 'B') && (
//           <View
//             style={{
//               width: dimensionsCalculation(365),
//               height: dimensionsCalculation(186),
//               backgroundColor: '#fff',
//               marginHorizontal: dimensionsCalculation(8),
//               borderRadius: dimensionsCalculation(12),
//               shadowColor: '#3B3B3B',
//               shadowOpacity: 0.13,
//               shadowRadius: 22,
//               shadowOffset: { height: 6, width: 0 },
//               elevation: 2,
//               paddingVertical: dimensionsCalculation(16),
//               justifyContent: 'space-between',
//             }}
//           >
//             <Text
//               style={{
//                 marginHorizontal: dimensionsCalculation(16),
//                 fontSize: dimensionsCalculation(16),
//                 color: '#005EB8',
//               }}
//             >
//               Achievements
//             </Text>
//             {this.state.achievments.length === 0 ? (
//               <View
//                 style={{
//                   flex: 1,
//                   justifyContent: 'center',
//                   alignItems: 'center',
//                 }}
//               >
//                 <Text
//                   style={{
//                     marginHorizontal: dimensionsCalculation(16),
//                     fontSize: dimensionsCalculation(16),
//                     color: '#005EB8',
//                   }}
//                 >
//                   You Don't have any Achievement yet!
//                 </Text>
//               </View>
//             ) : (
//               <FlatList
//                 showsHorizontalScrollIndicator={false}
//                 horizontal={true}
//                 data={this.state.achievments}
//                 renderItem={this.renderAchievmentCard}
//                 keyExtractor={(item, index) => item.reason.toString()}
//               />
//             )}
//           </View>
//         )}
//       </View>
//     );
//   };

//   renderAchievmentCard = ({ item, index }) => {
//     return (
//       <View
//         style={{
//           marginHorizontal: dimensionsCalculation(9),
//           alignItems: 'center',
//         }}
//       >
//         <View
//           style={{
//             marginVertical: dimensionsCalculation(16),
//             width: dimensionsCalculation(80),
//             height: dimensionsCalculation(80),
//             backgroundColor: '#fff',
//             borderRadius: dimensionsCalculation(40),
//             shadowColor: '#8A8A8A',
//             shadowOpacity: 0.2,
//             shadowRadius: 22,
//             shadowOffset: { height: 6, width: 6 },
//             elevation: 2,
//             justifyContent: 'space-around',
//             alignItems: 'center',
//             padding: dimensionsCalculation(8),
//           }}
//         >
//           <View
//             style={{
//               width: dimensionsCalculation(30),
//               height: dimensionsCalculation(30),
//             }}
//           >
//             {item.icon && (
//               <Image
//                 source={{ uri: item.icon }}
//                 style={{ width: '100%', height: '100%', tintColor: item.color }}
//                 resizeMode="contain"
//               />
//             )}
//           </View>
//           <Text style={{ color: item.color, fontSize: dimensionsCalculation(18) }}>
//             {item.total}
//           </Text>
//         </View>
//         <Text style={{ fontSize: dimensionsCalculation(16), color: '#005EB8' }}>
//           {item.reason}
//         </Text>
//       </View>
//     );
//   };

//   renderPost = ({ item }) => {
//     return (
//       <Post
//         componentId={this.props.componentId}
//         item={item}
//         myProfile={this.props.myProfile}
//         user={this.state.user}
//       />
//     );
//   };

//   renderFooter = () => {
//     const postsData = this.props.postsByUserId[this.state.user.id] || {};
//     if (postsData.pending && !this.state.isRefreshing)
//       return <ActivityIndicator size="large" style={{ paddingTop:dimensionsCalculation(40), paddingBottom:dimensionsCalculation(40) }}/>;
//     else return null;
//   };

//   renderEmpty = () => {
//     const postsData = this.props.postsByUserId[this.state.user.id] || {};
//     if (postsData.success && postsData.list && postsData.list.length === 0)
//       return (
//         <View style={{ flexDirection: "row", justifyContent: 'center', marginTop: dimensionsCalculation(5) }}>
//           <Text style={{ fontSize: 20 }}> No posts added yet</Text>
//         </View>
//       );
//     return null;
//   };

//   fetchMore = () => {
//     if (this.state.nextPage && this.state.currentPage !== this.state.lastPage) {
//       this.setState({ lastPage: this.state.currentPage }, () => {
//         this.props.getUserProfile({
//           userId: this.state.user.id,
//           page: this.state.currentPage + 1,
//         });
//       });
//     }
//   };

//   handlePressBack = () => {
//     if (this.props.myProfile) return;
//     else pop(this.props.componentId);
//   };

//   renderAddPost = () => {
//     return (
//       <View
//         style={{
//           position: 'absolute',
//           bottom: -dimensionsCalculation(50),
//           zIndex: 99998,
//           alignSelf: 'center',
//           marginTop: dimensionsCalculation(8),
//           marginBottom: dimensionsCalculation(24),
//         }}
//       >
//         <TouchableOpacity
//           onPress={() => {
//             push(
//               this.props.componentId,
//               screenIds.ADD_POST_SCREEN,
//               {},
//               {
//                 bottomTabs: {
//                   visible: false,
//                   animate: true,
//                   drawBehind: true,
//                 },
//               }
//             );
//           }}
//           activeOpacity={1}
//           style={{
//             height: dimensionsCalculation(60),
//             width: dimensionsCalculation(365),
//             backgroundColor: '#fff',
//             borderRadius: dimensionsCalculation(12),
//             shadowColor: '#3B3B3B',
//             shadowOpacity: 0.22,
//             shadowRadius: 22,
//             shadowOffset: { height: 6, width: 0 },
//             elevation: 2,
//             flexDirection: 'row',
//             alignItems: 'center',
//             paddingHorizontal: dimensionsCalculation(24),
//           }}
//         >
//           <View
//             style={{
//               width: dimensionsCalculation(40),
//               height: dimensionsCalculation(40),
//               borderRadius: dimensionsCalculation(20),
//               shadowColor: '#000000',
//               shadowOpacity: 0.22,
//               shadowRadius: 8,
//               shadowOffset: { height: 3, width: 0 },
//               elevation: 2,
//             }}
//           >
//             {this.props.userProfile.image && (
//               <FastImage
//                 source={{ uri: this.props.userProfile.image }}
//                 style={{
//                   width: '100%',
//                   height: '100%',
//                   borderRadius: dimensionsCalculation(20),
//                 }}
//                 resizeMode="cover"
//               />
//             )}
//           </View>
//           <View style={{ flex: 1, paddingHorizontal: dimensionsCalculation(16) }}>
//             <Text
//               style={{
//                 flexWrap: 'wrap',
//                 fontSize: dimensionsCalculation(15),
//                 color: '#717171',
//                 lineHeight: dimensionsCalculation(20),
//                 letterSpacing: dimensionsCalculation(0.2),
//               }}
//             >
//               add post ...
//             </Text>
//           </View>
//         </TouchableOpacity>
//       </View>
//     );
//   };

//   render() {
//     let showAddPost = false;
//     if (
//       this.props.userProfile &&
//       this.props.userProfile.position &&
//       this.props.userProfile.position.layer !== 'C'
//     ) {
//       showAddPost = true;
//     }

//     return (
//       <SafeAreaView style={{ flex: 1, backgroundColor: '#005EB8' }}>
//         {/* Header replacement for HStack */}
//         <View
//           style={[
//             {
//               paddingHorizontal: dimensionsCalculation(16),
//               backgroundColor: '#005EB8',
//               borderBottomWidth: 0,
//               justifyContent: 'space-between',
//               alignItems: 'flex-start',
//               paddingTop: dimensionsCalculation(30),
//               flexDirection: 'row',
//             },
//             Platform.OS === 'android' ? { height: dimensionsCalculation(70) } : {},
//           ]}
//         >
//           {this.props.profile ? (
//             <TouchableOpacity onPress={() => pop(this.props.componentId)} style={{ flexDirection: 'row' }}>
//               {this.props.myProfile ? null : (
//                 <Image style={{ marginLeft: 10 }} source={require('../../assets/icons/left_arrow.png')} />
//               )}
//               <Text
//                 style={{
//                   fontSize: dimensionsCalculation(20),
//                   letterSpacing: dimensionsCalculation(0.2),
//                   lineHeight: dimensionsCalculation(25),
//                   color: '#fff',
//                   fontWeight: 'bold',
//                   marginHorizontal: this.props.myProfile ? 0 : dimensionsCalculation(8),
//                 }}
//               >
//                 Profile
//               </Text>
//             </TouchableOpacity>
//           ) : (
//             <View style={{ flexDirection: 'row' }}>
//               {this.props.myProfile ? null : (
//                 <Image style={{ marginLeft: 10 }} source={require('../../assets/icons/left_arrow.png')} />
//               )}
//               <Text
//                 style={{
//                   fontSize: dimensionsCalculation(20),
//                   letterSpacing: dimensionsCalculation(0.2),
//                   lineHeight: dimensionsCalculation(25),
//                   color: '#fff',
//                   fontWeight: 'bold',
//                   marginHorizontal: this.props.myProfile ? 0 : dimensionsCalculation(8),
//                 }}
//               >
//                 {this.props.userProfile &&
//                 this.props.userProfile.position &&
//                 this.props.userProfile.position.layer === 'A' ||
//                 this.props.userProfile &&
//                 this.props.userProfile.position &&
//                 this.props.userProfile.position.layer === 'B'
//                   ? 'Allocation Of Qcoins'
//                   : 'My Achievements'}
//               </Text>
//             </View>
//           )}
//           {this.props.myProfile ? (
//             <TouchableOpacity
//               hitSlop={{ top: 8, bottom: 8, left: 8, right: 8 }}
//               onPress={() =>
//                 push(
//                   this.props.componentId,
//                   screenIds.SETTING_SCREEN,
//                   { user: this.state.user },
//                   {
//                     bottomTabs: {
//                       visible: false,
//                       animate: false,
//                       drawBehind: true,
//                     },
//                   }
//                 )
//               }
//               style={{ width: dimensionsCalculation(20), height: dimensionsCalculation(20) }}
//             >
//               <Image
//                 source={require('../../assets/icons/settings.png')}
//                 style={{ width: '100%', height: '100%' }}
//               />
//             </TouchableOpacity>
//           ) : null}
//         </View>
//         <View
//           style={{
//             backgroundColor: '#FFFFFF',
//             marginBottom: dimensionsCalculation(90),
//           }}
//         >
//           {this.renderHeaderSection(showAddPost)}
//           <FlatList
//             style={showAddPost ? { zIndex: 9, paddingTop: dimensionsCalculation(60) } : { marginTop: -dimensionsCalculation(50) }}
//             showsVerticalScrollIndicator={false}
//             bounces={false}
//             data={this.state.posts}
//             contentContainerStyle={{}}
//             renderItem={this.renderPost}
//             keyExtractor={(item, index) => (item.id + 'jojo22' + index).toString()}
//             ListFooterComponent={this.renderFooter}
//             ListEmptyComponent={this.renderEmpty}
//             ListHeaderComponent={this.showAchievements}
//             initialNumToRender={2}
//             onEndReachedThreshold={0.7}
//           />
//         </View>

//       </SafeAreaView>
//     );
//   }
// }

// export default ProfileScreen;