// @flow

import React, { PureComponent, Component } from "react";
import {
  StyleSheet,
  View,
  Image,
  Text,
  Dimensions,
  FlatList,
  TouchableOpacity,
  Platform,
  RefreshControl,
  TouchableWithoutFeedback,
  SafeAreaView,
} from "react-native";
// import FastImage from "@d11/react-native-fast-image";
import { showModal, screenIds, goToLogin, push } from "../../navigation";

const { width, height } = Dimensions.get("window");
const dimensionsCalculation = (IPhonePixel) => {
  return (width * IPhonePixel) / 375;
};

const styles = StyleSheet.create({
  flex: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
  },
  button: {
    backgroundColor: "#039893",
    width: 230,
    marginTop: 30,
    borderRadius: 25,
  },
  buttonTitle: {
    fontSize: 14,
    fontWeight: "bold",
  },
  logo: {
    width: 300,
    height: 120,
    resizeMode: "contain",
  },
  logoTitle: {
    marginTop: 10,
    fontSize: 16,
    fontWeight: "500",
  },
});

class NotificationScreen extends Component {
  componentDidMount() {
    this.props.getNotification({});
  }

  constructor(props) {
    super(props);
    this.state = {
      isRefreshing: false,
    };
  }

  // componentWillReceiveProps(nextProps) {}

  renderNotification = ({ item }) => {
    const icon = item.icon;
    const {
      created_at = "",
      body,
      from_user = {},
      click_action = "",
    } = item || {};
    const { image = "" } = from_user || {};
    const navigate_to =
      item.body && item.body.includes("Request")
        ? screenIds.SETTING_SCREEN
        : screenIds.POST_SCREEN;
    return (
      <TouchableWithoutFeedback
        onPress={
          item.click_action == "0" && !item.body.includes("Request")
            ? () => {}
            : () => {
                push(
                  this.props.componentId,
                  navigate_to,
                  {
                    id: click_action,
                    comments: item.body.includes("Commented"),
                    // user: this.state.user
                  },
                  {
                    layout: {
                      backgroundColor: "#fff",
                    },
                    modalPresentationStyle: "overCurrentContext",
                    statusBar: {
                      style: "dark",
                      backgroundColor: "#005EB8",
                    },
                  }
                );
              }
        }
      >
        <View
          style={{
            flex: 1,
            padding: dimensionsCalculation(16),
            backgroundColor: "#FFFFFF",
          }}
        >
          <View style={{ flex: 1, flexDirection: "row" }}>
            <View
              style={{
                width: dimensionsCalculation(50),
                height: dimensionsCalculation(50),
                borderRadius: dimensionsCalculation(25),
              }}
            >
              {/* <FastImage
                source={{ uri: icon ? icon : image }}
                style={{
                  width: "100%",
                  height: "100%",
                  borderRadius: dimensionsCalculation(25),
                }}
                resizeMode="cover"
              /> */}
            </View>
            <View
              style={{
                flex: 1,
                paddingHorizontal: dimensionsCalculation(4),
                paddingTop: dimensionsCalculation(4),
              }}
            >
              {/* <Text style={{ fontSize: dimensionsCalculation(16), color: '#707070', }}>Hamzeh Dan */}
              <Text
                style={{
                  fontSize: dimensionsCalculation(14),
                  color: "#929292",
                  flexWrap: "wrap",
                  flex: 1,
                }}
              >
                {body}
              </Text>
              {/* </Text> */}
            </View>
          </View>
          <View
            style={{
              flex: 1,
              alignItems: "flex-end",
              justifyContent: "flex-end",
              paddingTop: dimensionsCalculation(4),
            }}
          >
            <Text style={{ color: "#CECECE" }}>
              {created_at ? created_at.split(" ")[0] : ""}
            </Text>
          </View>
        </View>
      </TouchableWithoutFeedback>
    );
  };

  renderEmpty = () => {
    if (this.props.notification.success)
      return (
        <View
          style={{
            flexDirection: "row",
            justifyContent: "center",
            marginTop: dimensionsCalculation(30),
          }}
        >
          <Text style={{ fontSize: 20, paddingBottom:10 }}>No Notifications </Text>
        </View>
      );
    return null;
  };

  render() {
    return (
      <GluestackUIProvider config={config}>
        <SafeAreaView style={{ backgroundColor: "#FCFCFC" }}>
          <HStack
            paddingHorizontal={dimensionsCalculation(16)}
            backgroundColor={"#005EB8"}
            borderBottomWidth={0}
            justifyContent={"flex-start"}
            height={dimensionsCalculation(100)}
            alignItems={"flex-start"}
            paddingTop={dimensionsCalculation(30)}
            style={
              Platform.OS == "android"
                ? { height: dimensionsCalculation(70) }
                : {}
            }
          >
            <Text
              style={{
                fontSize: dimensionsCalculation(20),
                letterSpacing: dimensionsCalculation(0.2),
                lineHeight: dimensionsCalculation(25),
                color: "#fff",
              }}
            >
              {"Notifications".toUpperCase()}
            </Text>
          </HStack>
          <FlatList
            style={{
              marginTop:
                Platform.OS == "android"
                  ? -dimensionsCalculation(10)
                  : -dimensionsCalculation(35),
              backgroundColor: "#FFFFFF",
              shadowColor: "#3B3B3B",
              shadowOpacity: 0.13,
              shadowRadius: 22,
              shadowOffset: {
                height: 6,
                width: 0,
              },
              elevation: 2,
              marginHorizontal: dimensionsCalculation(16),
              borderTopEndRadius: dimensionsCalculation(16),
              borderTopStartRadius: dimensionsCalculation(16),
            }}
            showsVerticalScrollIndicator={false}
            data={this.props.notification.list}
            contentContainerStyle={{}}
            renderItem={this.renderNotification}
            keyExtractor={(item, index) =>
              (item.id + "jojo22lkk" + index).toString()
            }
            ListFooterComponent={this.renderFooter}
            ListEmptyComponent={this.renderEmpty}
            // initialNumToRender={2}
            onEndReachedThreshold={0.7}
            refreshControl={
              <RefreshControl
                refreshing={this.state.isRefreshing}
                onRefresh={() => {
                  this.setState({ isRefreshing: true }, () => {
                    this.props.getNotification({});
                    this.setState({ isRefreshing: false });
                  });
                }}
              />
            }
          />
        </SafeAreaView>
      </GluestackUIProvider>
    );
  }
}

export default NotificationScreen;
