import { connect } from 'react-redux';
import WelcomeMessageScreen from './WelcomeMessageScreen';

export default WelcomeMessageScreen;