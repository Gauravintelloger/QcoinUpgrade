// @flow

import React, { PureComponent } from 'react';
import {
  StyleSheet,
  View,
  Image,
  Text,
  Dimensions,
  ScrollView,
  TouchableOpacity,
} from 'react-native';
// import FastImage from '@d11/react-native-fast-image';
import { GluestackUIProvider, HStack, Box } from "@gluestack-ui/themed";

import AsyncStorage from '@react-native-async-storage/async-storage';

const { width, height } = Dimensions.get('window');
const dimensionsCalculation = IPhonePixel => {
  return (width * IPhonePixel) / 375;
};

const styles = StyleSheet.create({
  flex: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
  },
  button: {
    backgroundColor: '#039893',
    width: 230,
    marginTop: 30,
    borderRadius: 25,
  },
  buttonTitle: {
    fontSize: 14,
    fontWeight: 'bold',
  },
  logo: {
    width: 300,
    height: 120,
    resizeMode: 'contain',
  },
  logoTitle: {
    marginTop: 10,
    fontSize: 16,
    fontWeight: '500',
  },
  text: {
    color: '#FFFFFF',
    lineHeight: dimensionsCalculation(35),
    letterSpacing: dimensionsCalculation(0.7),
    fontSize: dimensionsCalculation(14),
  },
});

class WelcomeMessageScreen extends PureComponent {
  handlePress = async () => {
    const { goToLogin, dismissModal } = ('../../navigation')
    await AsyncStorage.setItem('firstTime', 'yes');
    goToLogin();
    dismissModal(this.props.componentId);
  };
  render() {
    return (
      <GluestackUIProvider>
      <View
        style={{
          backgroundColor: '#0091DA',
          paddingLeft: dimensionsCalculation(24),
          flex: 1,
        }}>
        <View style={{ flex: 1, backgroundColor: '#005EB8' }}>
          <ScrollView
            showsVerticalScrollIndicator={false}
            style={{ height: '100%' }}>
            <View style={{ marginBottom: dimensionsCalculation(32) }}>
              {/* <View>
                <FastImage
                  source={('../../assets/images/logo.png')}
                  style={{
                    width: dimensionsCalculation(147),
                    height: dimensionsCalculation(63),
                  }}
                />
              </View> */}
              <View style={{ paddingHorizontal: dimensionsCalculation(24) }}>
                <View
                  style={{
                    width: dimensionsCalculation(180),
                    marginBottom: dimensionsCalculation(24),
                  }}>
                  <Text
                    style={{
                      fontSize: dimensionsCalculation(20),
                      flexWrap: 'wrap',
                      color: '#FFFFFF',
                      lineHeight: dimensionsCalculation(25),
                      letterSpacing: dimensionsCalculation(4),
                    }}>
                    Welcome to the Qcoin App
                  </Text>
                </View>
                <View style={{ marginBottom: dimensionsCalculation(32) }}>
                  <Text style={styles.text}>
                    Quality Points is the currency we use to reward audit
                    quality and this App will help you in keeping the score and
                    record feedback. This year, your manager group will have a
                    wallet full of Qcoins for you. The more you contribute to
                    audit quality, the more qcoins you can earn.
                  </Text>
                  <Text style={styles.text}>
                    Let’s enhance the audit quality and get rewarded
                    {/* <View
                      style={{
                        width: dimensionsCalculation(29),
                        height: dimensionsCalculation(29),
                      }}> */}
                    <Image
                      source={('../../assets/icons/like_splash.png')}
                      style={{
                        width: dimensionsCalculation(24),
                        height: dimensionsCalculation(20),
                      }}
                    />
                    {/* </View> */}
                  </Text>
                </View>
                <View styles={{ marginBottom: dimensionsCalculation(24) }}>
                  <Text style={styles.text}>Muhammad Tariq</Text>
                  <Text style={styles.text}>
                    Head of Audit – Saudi Levant Cluster
                  </Text>
                </View>
                <View>
                  <Text style={styles.text}>Kashif Zafar</Text>
                  <Text style={styles.text}>
                    Audit COO – Saudi Levant Cluster
                  </Text>
                </View>
              </View>
            </View>
          </ScrollView>
        </View>
        <HStack
            height= {dimensionsCalculation(40)}
            backgroundColor= {'#005EB8'}
            borderTopWidth= {0}
            justifyContent= {'flex-end'}
          >
          <TouchableOpacity
            onPress={this.handlePress}
            style={{
              alignItems: 'center',
              paddingHorizontal: dimensionsCalculation(24),
              flexDirection: 'row',
            }}>
            <Text
              style={{
                color: '#fff',
                fontSize: dimensionsCalculation(21),
                lineHeight: dimensionsCalculation(25),
                marginHorizontal: dimensionsCalculation(8),
              }}>
              SKIP
            </Text>
            <Image source={('../../assets/icons/right_arrow.png')} />
          </TouchableOpacity>
        </HStack>
      </View>
      </GluestackUIProvider>
    );
  }
}

export default WelcomeMessageScreen;
